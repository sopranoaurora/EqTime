import datetime,time

def date_raw():
    epoch = datetime.datetime.utcfromtimestamp(0)
    today = datetime.datetime.today()
    days = today - epoch
    dayssince = days.days
    return dayssince

def time_raw():
    
    time = datetime.datetime.now().time()
    ts = time.hour * 3600 + time.minute * 60 + time.second
    eqtime = ts / 0.864
    return str(round(int(eqtime)))

def insert(original, new, pos):

    return original[:pos] + new + original[pos:]

def eqtime():
    i = 0
    x = str(time_raw()).zfill(5)
    z = -2


    while i < 2:
        i = i + 1
        z = z + 3
        x = insert(x,":",z)
    return x

def eqdate():
    
    year = str(date_raw())[:3]
    month = str(date_raw()+1)[3]
    day = str(date_raw())[4]

    if day == "0":
        day = "10"
        month = str(int(month) - 1)
    if month == "0":
        month = "10"
        year = str(int(year) - 1)
    return day.zfill(2) + "/" + month.zfill(2) + "/" + year

def start():
	print(eqtime())
	print(eqdate())
	


