import datetime, time


def eq2date(date,time):
    days = int(date[:2]) - 1
    months = int(date[3:][:2])
    years = int(date[6:][:3])

    hours = int(str(time)[:1])
    minutes = int(str(time)[2:][:2])
    seconds = int(str(time)[5:][:7])

    if days == 10:
        days = 0

    if months == 10:
        months = 0
        years = years - 1

    dayssince = int(str(years) + str(months) + str(days))

   

    secondssince = round(int(time.replace(":","")) * 0.864)




    

    seconds_since_epoch = int((((dayssince * 24) * 60) * 60))

    unix = seconds_since_epoch + secondssince

    date_final = datetime.datetime.fromtimestamp(int(unix+46800)).strftime('%d-%m-%Y %H:%M:%S')
    
 
    return date_final
    
    
def start():
	x = input("Enter time [H:MM:SS]: ")
	y = input("Enter date [DD/MM/YYY]: ")


	print(eq2date(y,x))
