import os

def convert(input):
    #Centimetre to Hoof
    microhoof = input / 0.00075 #0
    millihoof = input / 0.0075 #1
    centihoof = input / 0.075 #2
    decihoof = input / 0.75 #3
    hoof = input / 7.5 #4
    dekahoof = input / 75 #5
    hectahoof = input / 750 #6
    kilohoof = input / 7500 #7
    megahoof = input / 75000 #8

    #Hoof to centimetre
    micrometre = input * 750 #9
    millimetre = input * 75 #10
    centimetre = input * 7.5 #11
    decimetre = input * 0.75 #12
    metre = input * 0.075 #13
    dekametre = input * 0.0075 #14
    hectametre = input * 0.000750 #15
    kilometre = input * 0.00007500 #16
    megametre = input * 0.0000075000 #17

    #Temperature
    sola = (input + 12) / 0.46 #18
    
    cel = (input * 0.46) - 12 #19

    #Volume
    millilun = input * 4.21 #20
    lun = input / 0.421 #21

    millilitre = input * 0.000421 #22
    litre = input * 0.421 #23

    return microhoof,millihoof,centihoof,decihoof,hoof,dekahoof,hectahoof,kilohoof,megahoof,micrometre,millimetre,centimetre,decimetre,metre,dekametre,hectametre,kilometre,megametre,sola,cel,millilun,lun,millilitre,litre


def start():
	x = input("Enter input (in centimetre, hoof, sola, or celsius): ")

	x = float(x)



	print("----HOOVES----")
	print("Microhoof: " + str(convert(x)[0]))
	print("Millihoof: " + str(convert(x)[1]))
	print("Centihoof: " + str(convert(x)[2]))
	print("Decihoof: " + str(convert(x)[3]))
	print("Hoof: " + str(convert(x)[4]))
	print("Dekahoof: " + str(convert(x)[5]))
	print("Hectahoof: " + str(convert(x)[6]))
	print("Kilohoof: " + str(convert(x)[7]))
	print("Megahoof: " + str(convert(x)[8]))

	print("----METRES----")

	print("Micrometre: " + str(convert(x)[9]))
	print("Millimetre: " + str(convert(x)[10]))
	print("Centimetre: " + str(convert(x)[11]))
	print("Decimetre: " + str(convert(x)[12]))
	print("Metre: " + str(convert(x)[13]))
	print("Dekametre: " + str(convert(x)[14]))
	print("Hectametre: " + str(convert(x)[15]))
	print("Kilometre: " + str(convert(x)[16]))
	print("Megametre: " + str(convert(x)[17]))

	print("----SOLA----")

	print("Sola: " + str(convert(x)[18]))

	print("----CELSIUS----")

	print("Celsius: " + str(convert(x)[19]))





















