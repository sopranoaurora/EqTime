import sys, co_eqtime, co_hutime, co_measure




if str(sys.argv[1]) == "-e":
	co_eqtime.start()
elif str(sys.argv[1]) == "-h":
	co_hutime.start()
elif str(sys.argv[1]) == "-m":
	co_measure.start()
else:
	print ("-e for Equestrian Time. -h for Human Time. -m for Measurement.")


